"use strict";
exports.id = 700;
exports.ids = [700];
exports.modules = {

/***/ 700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MainContent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/projects/waysbeans.webp
/* harmony default export */ const waysbeans = ({"src":"/_next/static/media/waysbeans.8120e702.webp","height":1100,"width":1920,"blurDataURL":"data:image/webp;base64,UklGRkgAAABXRUJQVlA4IDwAAACwAQCdASoIAAUAAkA4JZQCdAEO/gLsAP75uoNqXVf8Qf9EGuX1gZd8tdF/y/rNkSgF53EU4ykHtwwgAAA=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/projects/landtick.jpg
/* harmony default export */ const landtick = ({"src":"/_next/static/media/landtick.e7c7e499.jpg","height":1153,"width":1898,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAKqC/wD/xAAaEAEAAgMBAAAAAAAAAAAAAAABAgQAISIx/9oACAEBAAE/AI0q8RCLv3pz/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAx/9oACAECAQE/AEHS/8QAGREAAQUAAAAAAAAAAAAAAAAAAAIDE1KR/9oACAEDAQE/AJHLq0//2Q==","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./src/components/mainContent.tsx








function MainContent() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center items-center min-h-screen gap-x-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "left-content flex flex-col gap-y-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " font-sans text-2xl font-semibold w-[400px] hover:bg-clip-text hover:text-transparent hover:bg-gradient-to-r hover:from-[#FFF1A5] hover:via-[#C87D4C] hover:to-[#533636] transition-all duration-700 border-b-2 border-dotted py-4",
                                children: [
                                    "An online marketplace ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "for coffee enthusiasts to discover  and purchase ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "premium coffee from around the globe"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-lg leading-[28px] font-bold",
                                children: "Waysbeans"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-x-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[13px] font-bold",
                                        children: "2023"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex gap-x-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://github.com/rakharan/Waysbeans",
                                                target: "_blank",
                                                className: " hover:bg-blue-300 rounded-full flex justify-center items-center p-[3px] transition-all duration-200",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineGithub, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://waysbeans-teal.vercel.app",
                                                target: "_blank",
                                                className: " hover:bg-blue-300 rounded-full flex justify-center items-center p-[3px] transition-all duration-200",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaGlobeAsia, {})
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "right-content w-[620px] flex items-center justify-center cursor-pointer shadow-xl rounded-xl overflow-hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://waysbeans-teal.vercel.app",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: waysbeans,
                                    alt: "waysbeans thumbnail",
                                    placeholder: "blur",
                                    className: " object-contain hover:scale-110 transition-all duration-300"
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center items-center min-h-screen gap-x-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "left-content flex flex-col gap-y-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " font-sans text-2xl font-semibold w-[400px] hover:bg-clip-text hover:text-transparent hover:bg-gradient-to-r hover:from-[#EC7AB7] hover:to-[#EC7A7A] transition-all duration-700 border-b-2 border-dotted py-4",
                                children: [
                                    "A web-based platform ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "that simplifies the process of booking ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "and managing train tickets for users."
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-lg leading-[28px] font-bold",
                                children: "LandTick"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-x-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[13px] font-bold",
                                        children: "2023"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex gap-x-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://github.com/rakharan/Final-Task",
                                                target: "_blank",
                                                className: " hover:bg-blue-300 rounded-full flex justify-center items-center p-[3px] transition-all duration-200",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineGithub, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://final-task-pi.vercel.app/",
                                                target: "_blank",
                                                className: " hover:bg-blue-300 rounded-full flex justify-center items-center p-[3px] transition-all duration-200",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaGlobeAsia, {})
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "right-content w-[620px] flex items-center justify-center cursor-pointer shadow-xl rounded-xl overflow-hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://final-task-pi.vercel.app/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: landtick,
                                    alt: "waysbeans thumbnail",
                                    placeholder: "blur",
                                    className: " object-contain hover:scale-110 transition-all duration-300"
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;