"use strict";
exports.id = 918;
exports.ids = [918];
exports.modules = {

/***/ 7453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/navbar.tsx



function Navbar() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "h-[114px]  w-full flex justify-between px-14",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "left-navbar  flex items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                    className: "text-5xl",
                                    children: [
                                        "R",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-bold",
                                            children: "."
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "right-navbar  flex items-center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex gap-x-[30px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/photography",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: " border-t-4 border-transparent hover:border-black transition-all duration-300 text-base p-2 leading-[50px] text-[12px]",
                                            children: "PHOTOGRAPHY"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/resume",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: " border-t-4 border-transparent hover:border-black transition-all duration-300 text-base p-2 leading-[50px] text-[12px]",
                                            children: "RESUME"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/layout.tsx




function Layout({ children , title  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            children
        ]
    });
}


/***/ })

};
;