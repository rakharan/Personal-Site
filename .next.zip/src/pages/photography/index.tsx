import Layout from '@/components/layout'
import React from 'react'

export default function Photography() {
    return (
        <>
            <Layout title='Photography | Rakha Randhikatama'>
                <main>

                </main>
            </Layout>
        </>
    )
}
